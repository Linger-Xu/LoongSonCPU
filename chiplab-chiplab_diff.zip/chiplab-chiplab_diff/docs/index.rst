.. chiplab documentation master file, created by
   sphinx-quickstart on Mon Apr 18 14:58:30 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to chiplab's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :numbered:

   Quick-Start
   Simulation/verilator
   Simulation/difftest
   FPGA_run_linux/linux_run
   FPGA_run_linux/flash
   Debug/debug

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
