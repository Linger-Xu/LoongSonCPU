# Chiplab用户手册 
## 前言
chiplab项目致力于构建基于LoongArch32 Reduced的soc敏捷开发平台。如发现问题请在issues提出。

详细介绍请参考[CHIPLAB使用介绍](https://chiplab.readthedocs.io/)
### 交流群
 [slack交流群](https://join.slack.com/t/chiplabworkspace/shared_invite/zt-v1927dwg-qqnHNTcAeko7QsUsdCRoPA)
