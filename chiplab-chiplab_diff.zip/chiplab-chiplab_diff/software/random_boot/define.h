
#define CACHE_WAY 2
#define CACHE_IDX 256
#define CACHE_OFFSET 4
