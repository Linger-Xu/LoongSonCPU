This folder contains the original, unaltered documents from the CoreMark V1.0 release.
