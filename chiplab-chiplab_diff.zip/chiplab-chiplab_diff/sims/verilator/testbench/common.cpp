#include "common.h"

/* CHIPLAB_HOME path, cannot be NULL */
const char* chiplab_home;
/* nemu path */
const char* difftest_ref_so;